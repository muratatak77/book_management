require 'simplecov'
SimpleCov.start

require 'sequenceserver'
