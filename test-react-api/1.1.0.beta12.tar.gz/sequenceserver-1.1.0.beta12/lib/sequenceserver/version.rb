# Define version number.
module SequenceServer
  VERSION = '1.1.0.beta12'.freeze
end
