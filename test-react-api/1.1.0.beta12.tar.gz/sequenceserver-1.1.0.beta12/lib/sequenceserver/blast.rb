require_relative 'blast/job'
require_relative 'blast/report'
require_relative 'blast/constants'
